﻿using Quixotic.Lexography.Tokens;

namespace Quixotic.Parsing.Exceptions
{
    public class TokenParsingException(string message, Token token) : ParserException($"Cannot parse token '{token}': {message}")
    {
        public Token Token { get; } = token;

        public Position Position { get; set; } = token.Position;
    }
    }
}
