﻿using Quixotic.Lexography.Tokens;
using Quixotic.Parsing.Expressions;

namespace Quixotic.Parsing.Statements
{
    public sealed class PrintStatement : Statement
    {
        public required Expression Expression { get; init; }

        public static PrintStatement Build(Stepper<Token> stepper)
        {
            var expression = Expression.GetRequiredExpression(stepper.Peek());

            return new()
            {
                Expression = expression
            };
        }
    }
}
