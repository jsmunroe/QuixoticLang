﻿namespace Quixotic.Parsing.Statements
{
    public abstract class Statement
    {
        public static Statement Start()
    }
}
