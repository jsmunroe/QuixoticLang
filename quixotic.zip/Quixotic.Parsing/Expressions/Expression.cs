﻿using Quixotic.Lexography.Tokens;
using Quixotic.Parsing.Exceptions;

namespace Quixotic.Parsing.Expressions
{
    public abstract class Expression
    {
        public static Expression GetRequiredExpression(Token token)
        {
            if (token.Type == TokenType.StringLiteral)
                return new StringLiteralExpression { Value = token.Value };

            if (token.Type == TokenType.NumberLiteral)
            {
                if (double.TryParse(token.Value, out var number))
                    return new NumberLiteralExpression { Value = number };

                throw new TokenParsingException("Failed to parse number literal token.", token);
            }

            throw new ParserException($"Unexpected token {token} when trying to parse an expression.");
        }
    }
}
