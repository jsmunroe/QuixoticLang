﻿namespace Quixotic.Parsing.Expressions
{
    public sealed class StringLiteralExpression : Expression
    {
        public required string Value { get; init; }
    }

    public sealed class NumberLiteralExpression : Expression
    {
        public required double Value { get; init; }
    }
}
