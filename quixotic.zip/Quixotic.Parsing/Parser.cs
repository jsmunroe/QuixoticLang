﻿using Quixotic.Lexography.Tokens;
using Quixotic.Parsing.Statements;

namespace Quixotic.Parsing
{
    public class Parser(IEnumerable<Token> tokens)
    {
        public Statement Parse(IEnumerable<Token> tokens)
        {
            var stepper = new Stepper<Token>(tokens);
        }

        public bool TryIdentifyNextStatement(Stepper<Token> stepper, out Statement? statement)
        {
            var next = stepper.Peek();

            if (next.Type == TokenType.Eof)
            {
                // TODO: Check for open blocks...
                statement = null;
                return false;
            }

            stepper.Advance();

            var nextStatement = next.Type switch
            {
                TokenType.Print => PrintStatement.Build(stepper),
                _ => throw new NotImplementedException($"Parsing for token type {next.Type} is not implemented yet.")

            };
        }
    }
}
