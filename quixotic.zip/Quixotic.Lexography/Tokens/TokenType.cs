﻿namespace Quixotic.Lexography.Tokens
{
    public enum TokenType
    {
        Print,
        StringLiteral,
        Identifier,
        NumberLiteral,
        If,
        Else,
        End,
        Equals,
        Plus,
        NewLine,
        Eof,
    }
}
